package com.web.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Boot05JpaRepositoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
