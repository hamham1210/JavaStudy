package com.web.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Boot07JpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
