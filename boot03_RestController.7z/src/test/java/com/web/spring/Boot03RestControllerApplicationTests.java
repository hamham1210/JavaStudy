package com.web.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Boot03RestControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
