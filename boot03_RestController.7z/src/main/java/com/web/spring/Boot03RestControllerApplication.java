package com.web.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Boot03RestControllerApplication {

	public static void main(String[] args) {
		SpringApplication.run(Boot03RestControllerApplication.class, args);
	}

}
