package com.web.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Workshop02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
