package com.web.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Workshop03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
